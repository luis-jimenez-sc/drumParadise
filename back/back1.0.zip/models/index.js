module.exports = {
    Hotel: require('./hotel.model'),
    Habitacion: require('./habitacion.model'),
    User: require('./usuario.model'),
    Factura: require('./factura.model'),
}